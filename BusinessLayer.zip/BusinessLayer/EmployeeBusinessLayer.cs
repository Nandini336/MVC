﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;

namespace BusinessLayer
{
    public class EmployeeBusinessLayer
    {
        public IEnumerable<Employee> employees
        {
            get
            {

                string connectionString = ConfigurationManager.ConnectionStrings["DBCS"].ConnectionString;
                List<Employee> employees = new List<Employee>();
                using (SqlConnection con = new SqlConnection(connectionString))
                {
                    con.Open();
                    using (SqlCommand cmd = new SqlCommand("select id,FirstName,LastName,city from employee", con))
                    {
                        //cmd.CommandType = CommandType.
                        SqlDataReader rdr = cmd.ExecuteReader();
                        while (rdr.Read())
                        {
                        //    if (rdr.HasRows)
                        //    {
                                Employee employee = new Employee();
                                employee.id = Convert.ToInt32(rdr["id"]);
                                employee.FirstName = rdr["FirstName"].ToString();
                                employee.LastName = rdr["LastName"].ToString();
                                employee.city = rdr["city"].ToString();

                                employees.Add(employee);

                            //}

                            //else
                            //{
                            //    break;
                            //}


                        }
                    }
                    return employees;
                }
                       
            }
        }
       
        
        
}
}
