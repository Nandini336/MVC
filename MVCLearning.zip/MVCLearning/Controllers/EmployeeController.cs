﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MVCLearning.Models;

namespace MVCLearning.Controllers
{
    public class EmployeeController : Controller
    {
        
        public ActionResult Details(int id)
        {
            //Employee employee = new Employee()
            //{
            //    EmployeeID = 336,
            //    FirstName="Nandini",
            //    LastName="Yarrala"

            //};
            EmployeeDataAccess employeeda = new EmployeeDataAccess();
            Employee employee=employeeda.Employees.Single(emp => emp.id == id);
            return View(employee);
        }

        public ActionResult Index(int departmentid)
        {
            EmployeeDataAccess employeeda = new EmployeeDataAccess();
            List<Employee> employees = employeeda.Employees.Where(emp => emp.DepartmentId == departmentid).ToList();
            return View(employees);
        }

        }
}