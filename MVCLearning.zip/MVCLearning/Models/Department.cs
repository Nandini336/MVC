﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations.Schema;
namespace MVCLearning.Models
{
   [Table("department")]
    public class Department
    {
        public int id { get; set; }
        public string Name { get; set; }
        public List<Employee> employees { get; set; }
    }
}