﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;

namespace MVCLearning.Models
{
    public class EmployeeDataAccess:DbContext //dbcontext establish connection 
    { 
        public DbSet<Employee> Employees { get; set; } //dbset returns all the set of employees through the EMPLOYEES property
        public DbSet<Department> departments { get; set; }
    }
}