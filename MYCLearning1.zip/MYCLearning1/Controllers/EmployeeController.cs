﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using BusinessLayer;
namespace MYCLearning1.Controllers
{
    public class EmployeeController : Controller
    {
        // GET: Employee
        public ActionResult Index()
        {
            EmployeeBusinessLayer employeebusinesslayer = new EmployeeBusinessLayer();
            List<Employee> employees = employeebusinesslayer.employees.ToList();
            return View(employees);
        }
    }
}